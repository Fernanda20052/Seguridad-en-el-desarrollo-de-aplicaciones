import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  DragDropModule,
  CdkDragDrop,
  moveItemInArray,
  transferArrayItem
} from '@angular/cdk/drag-drop';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';

import { TaskDto } from '../../models/task.model';
import { TaskService } from '../../services/task.service';
import { CreateTaskDialogComponent } from '../create-task-dialog/create-task-dialog.component';

@Component({
  selector: 'app-kanban',
  standalone: true,
  imports: [
    CommonModule,
    DragDropModule,
    MatCardModule,
    MatIconModule,
    MatButtonModule,
    MatDialogModule
  ],
  templateUrl: './kanban.component.html',
  styleUrls: ['./kanban.component.scss']
})
export class KanbanComponent implements OnInit {

  todo: TaskDto[] = [];
  done: TaskDto[] = [];

  constructor(
    private taskService: TaskService,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.loadTasks();
  }

openDialog(): void {

  const dialogRef = this.dialog.open(CreateTaskDialogComponent, {
    width: '500px',
    disableClose: true
  });

  dialogRef.afterClosed().subscribe(result => {

    if (!result) {
      return;
    }

    this.taskService.createTask(result).subscribe({
      next: () => {

        this.loadTasks();

        alert('La tarea se creó correctamente');

      },
      error: (err) => {

        console.error('Error al crear tarea', err);

        alert('Ocurrió un error al crear la tarea');

      }
    });

  });
}

  loadTasks(): void {
    this.taskService.getTasks().subscribe({
      next: (tasks) => {
        this.todo = tasks.filter(t => !t.isCompleted);
        this.done = tasks.filter(t => t.isCompleted);
      },
      error: (err) => {
        console.error('Error al cargar tareas', err);
      }
    });
  }

  drop(event: CdkDragDrop<TaskDto[]>) {

    if (event.previousContainer === event.container) {

      moveItemInArray(
        event.container.data,
        event.previousIndex,
        event.currentIndex
      );

    } else {

      const task = event.previousContainer.data[event.previousIndex];

      this.taskService.completeTask(task.id).subscribe({
        next: () => {

          transferArrayItem(
            event.previousContainer.data,
            event.container.data,
            event.previousIndex,
            event.currentIndex
          );

        },
        error: (err) => {
          console.error('No se pudo actualizar la tarea', err);
        }
      });

    }
  }
}