import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-create-task-dialog',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule
  ],
  templateUrl: './create-task-dialog.component.html',
  styleUrls: ['./create-task-dialog.component.scss']
})
export class CreateTaskDialogComponent {

  title = '';
  description = '';

  titleError = false;
  descriptionError = false;

  constructor(
    private dialogRef: MatDialogRef<CreateTaskDialogComponent>
  ) {}

  save(): void {

    this.titleError = !this.title.trim();
    this.descriptionError = !this.description.trim();

    if (this.titleError || this.descriptionError) {
      return;
    }

    this.dialogRef.close({
      title: this.title.trim(),
      description: this.description.trim()
    });
  }

  cancel(): void {
    this.dialogRef.close();
  }
}